Running "chmod a+x VennPainter.sh" to make VennPainter.sh executable
then running VennPainter.sh to execute VennPainter
